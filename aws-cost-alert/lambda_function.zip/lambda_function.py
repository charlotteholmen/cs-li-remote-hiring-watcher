import boto3
import json
import urllib.request
from datetime import datetime, timedelta
import os

SLACK_WEBHOOK_URL = os.environ["SLACK_WEBHOOK_URL"]

ce = boto3.client("ce")


def get_top_services(start, end):
    data = ce.get_cost_and_usage(
        TimePeriod={"Start": start, "End": end},
        Granularity="MONTHLY",
        Metrics=["UnblendedCost"],
        GroupBy=[{"Type": "DIMENSION", "Key": "SERVICE"}]
    )

    groups = data["ResultsByTime"][0]["Groups"]
    services = sorted(
        [(g["Keys"][0], float(g["Metrics"]["UnblendedCost"]["Amount"]))
         for g in groups],
        key=lambda x: x[1],
        reverse=True
    )
    return services[:5]


def lambda_handler(event, context):
    today = datetime.utcnow()
    
    # Format AWS time for display
    aws_time = today.strftime("%Y-%m-%d %H:%M:%S UTC")

    # Actual spend period = Month start → today
    actual_start = today.replace(day=1).strftime("%Y-%m-%d")
    actual_end = (today + timedelta(days=1)).strftime("%Y-%m-%d")

    # Actual spend
    actual_data = ce.get_cost_and_usage(
        TimePeriod={"Start": actual_start, "End": actual_end},
        Granularity="MONTHLY",
        Metrics=["UnblendedCost"]
    )
    actual_spend = float(
        actual_data["ResultsByTime"][0]["Total"]["UnblendedCost"]["Amount"])

    # Forecast start = today
    forecast_start = today.strftime("%Y-%m-%d")
    forecast_end = actual_end

    forecast_data = ce.get_cost_forecast(
        TimePeriod={"Start": forecast_start, "End": forecast_end},
        Metric="UNBLENDED_COST",
        Granularity="MONTHLY"
    )
    forecast_spend = float(
        forecast_data["ForecastResultsByTime"][0]["MeanValue"])

    # Top services
    top_services = get_top_services(actual_start, actual_end)
    services_text = "\n".join(
        [f"{i+1}. {s[0]} — ${s[1]:.2f}" for i, s in enumerate(top_services)])

    msg = (
        f"🚨 *AWS Cost Report*\n"
        f"*Report Time:* {aws_time}\n"
        f"*Actual Spend:* ${actual_spend:.2f}\n"
        f"*Forecast:* ${forecast_spend:.2f}\n"
        f"*Top Services:*\n{services_text}"
    )

    # Send the message to Slack
    req = urllib.request.Request(
        SLACK_WEBHOOK_URL,
        data=json.dumps({"text": msg}).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    urllib.request.urlopen(req)

    return {"status": "sent"}
